module Lambda where

import Data.List (nub, (\\))

data Lambda
  = Var String
  | App Lambda Lambda
  | Abs String Lambda
  | Macro String

instance Show Lambda where
  show (Var x)     = x
  show (App e1 e2) = "(" ++ show e1 ++ " " ++ show e2 ++ ")"
  show (Abs x e)   = "λ" ++ x ++ "." ++ show e
  show (Macro x)   = x

instance Eq Lambda where
  e1 == e2 = eq e1 e2 ([], [], [])
    where
      eq (Var x) (Var y) (env, xb, yb)     = elem (x, y) env || not (elem x xb || elem y yb)
      eq (App e1 e2) (App f1 f2) env       = eq e1 f1 env && eq e2 f2 env
      eq (Abs x e) (Abs y f) (env, xb, yb) = eq e f ((x, y) : env, x : xb, y : yb)
      eq (Macro x) (Macro y) _             = x == y
      eq _ _ _                             = False

vars :: Lambda -> [String]
vars (Var x)     = [x]
vars (App e1 e2) = nub (vars e1 ++ vars e2)
vars (Abs x e)   = nub (x : vars e)
vars _           = []

freeVars :: Lambda -> [String]
freeVars (Var x)     = [x]
freeVars (App e1 e2) = nub (freeVars e1 ++ freeVars e2)
freeVars (Abs x e)   = freeVars e \\ [x]
freeVars _           = []

newVar :: [String] -> String
newVar xs = head [s | s <- candidates, s `notElem` xs]
  where
    letters    = map (: []) ['a' .. 'z']
    candidates = concat (iterate grow letters)
    grow prev  = [a ++ b | a <- letters, b <- prev]

isNormalForm :: Lambda -> Bool
isNormalForm (App (Abs _ _) _) = False
isNormalForm (App e1 e2)       = isNormalForm e1 && isNormalForm e2
isNormalForm (Abs _ e)         = isNormalForm e
isNormalForm _                 = True

reduce :: String -> Lambda -> Lambda -> Lambda
reduce x (Var y) e
  | x == y    = e
  | otherwise = Var y
reduce x (App e1 e2) e = App (reduce x e1 e) (reduce x e2 e)
reduce x (Abs y body) e
  | x == y         = Abs y body
  | y `notElem` fv = Abs y (reduce x body e)
  | otherwise      = Abs z (reduce x (reduce y body (Var z)) e)
  where
    fv = freeVars e
    z  = newVar (fv ++ freeVars body ++ [x])
reduce _ m _ = m

normalStep :: Lambda -> Lambda
normalStep (App (Abs x body) e) = reduce x body e
normalStep (App e1 e2)
  | not (isNormalForm e1) = App (normalStep e1) e2
  | otherwise             = App e1 (normalStep e2)
normalStep (Abs x e) = Abs x (normalStep e)
normalStep e         = e

applicativeStep :: Lambda -> Lambda
applicativeStep (App (Abs x body) e)
  | isNormalForm body && isNormalForm e = reduce x body e
applicativeStep (App e1 e2)
  | not (isNormalForm e1) = App (applicativeStep e1) e2
  | otherwise             = App e1 (applicativeStep e2)
applicativeStep (Abs x e) = Abs x (applicativeStep e)
applicativeStep e         = e

simplify :: (Lambda -> Lambda) -> Lambda -> [Lambda]
simplify step e
  | isNormalForm e = [e]
  | otherwise      = e : simplify step (step e)

normal :: Lambda -> [Lambda]
normal = simplify normalStep

applicative :: Lambda -> [Lambda]
applicative = simplify applicativeStep
