module Code where

import Lambda

type Context = [(String, Lambda)]

data Line
  = Eval Lambda
  | Binding String Lambda
  deriving (Eq)

instance Show Line where
  show (Eval l)      = show l
  show (Binding s l) = s ++ " = " ++ show l

expand :: Context -> Lambda -> Either String Lambda
expand ctx (Macro name) = case lookup name ctx of
  Just e  -> expand ctx e
  Nothing -> Left name
expand ctx (App e1 e2) = App <$> expand ctx e1 <*> expand ctx e2
expand ctx (Abs x e)   = Abs x <$> expand ctx e
expand _   e           = Right e

simplifyCtx :: Context -> (Lambda -> Lambda) -> Lambda -> Either String [Lambda]
simplifyCtx ctx step e = simplify step <$> expand ctx e

normalCtx :: Context -> Lambda -> Either String [Lambda]
normalCtx ctx = simplifyCtx ctx normalStep

applicativeCtx :: Context -> Lambda -> Either String [Lambda]
applicativeCtx ctx = simplifyCtx ctx applicativeStep
