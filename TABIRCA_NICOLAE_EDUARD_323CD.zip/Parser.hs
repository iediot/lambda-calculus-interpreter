module Parser where

import Control.Applicative
import Data.Char (isDigit, isLower, isUpper)

import Lambda
import Code

newtype Parser a = Parser { parse :: String -> Maybe (a, String) }

instance Functor Parser where
  fmap f (Parser p) = Parser (fmap (\(a, s) -> (f a, s)) . p)

instance Applicative Parser where
  pure x = Parser (\s -> Just (x, s))
  Parser pf <*> Parser pa = Parser $ \s -> do
    (f, r1) <- pf s
    (a, r2) <- pa r1
    pure (f a, r2)

instance Monad Parser where
  Parser p >>= f = Parser $ \s -> do
    (a, r) <- p s
    parse (f a) r

instance Alternative Parser where
  empty = Parser (const Nothing)
  Parser p <|> Parser q = Parser (\s -> p s <|> q s)

sat :: (Char -> Bool) -> Parser Char
sat pred = Parser $ \s -> case s of
  c : cs | pred c -> Just (c, cs)
  _               -> Nothing

ch :: Char -> Parser Char
ch c = sat (== c)

varName :: Parser String
varName = some (sat isLower)

macroName :: Parser String
macroName = some (sat (\c -> isUpper c || isDigit c))

atom :: Parser Lambda
atom = paren <|> (Var <$> varName) <|> (Macro <$> macroName)
  where paren = ch '(' *> lambda <* ch ')'

app :: Parser Lambda
app = foldl App <$> atom <*> many (ch ' ' *> atom)

abst :: Parser Lambda
abst = Abs <$> (ch '\\' *> varName) <* ch '.' <*> lambda

lambda :: Parser Lambda
lambda = abst <|> app

parseLambda :: String -> Lambda
parseLambda s = case parse lambda s of
  Just (e, "") -> e
  _            -> error "parse error"

parseLine :: String -> Either String Line
parseLine s = case parse line s of
  Just (l, "") -> Right l
  _            -> Left s
  where
    line    = binding <|> (Eval <$> lambda)
    binding = Binding <$> macroName <* ch '=' <*> lambda
    