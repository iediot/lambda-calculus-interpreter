module DeBruijn where

import Data.List (elemIndex)
import Lambda (Lambda(..))

type Context = [String]

data DeBruijn
  = DBVar Int
  | DBFree String
  | DBApp DeBruijn DeBruijn
  | DBAbs String DeBruijn

instance Show DeBruijn where
  show (DBVar n)     = show n
  show (DBFree x)    = x
  show (DBApp e1 e2) = "(" ++ show e1 ++ " " ++ show e2 ++ ")"
  show (DBAbs _ e)   = "λ " ++ show e

instance Eq DeBruijn where
  DBVar n     == DBVar m     = n == m
  DBFree _    == DBFree _    = True
  DBApp e1 e2 == DBApp f1 f2 = e1 == f1 && e2 == f2
  DBAbs _ e   == DBAbs _ f   = e == f
  _           == _           = False

toDB :: Context -> Lambda -> DeBruijn
toDB ctx (Var x)     = maybe (DBFree x) DBVar (elemIndex x ctx)
toDB ctx (App e1 e2) = DBApp (toDB ctx e1) (toDB ctx e2)
toDB ctx (Abs x e)   = DBAbs x (toDB (x : ctx) e)
toDB _   (Macro m)   = DBFree m

fromDB :: Context -> DeBruijn -> Lambda
fromDB ctx (DBVar n)     = Var (ctx !! n)
fromDB _   (DBFree x)    = Var x
fromDB ctx (DBApp e1 e2) = App (fromDB ctx e1) (fromDB ctx e2)
fromDB ctx (DBAbs x e)   = Abs x (fromDB (x : ctx) e)

isNormalForm :: DeBruijn -> Bool
isNormalForm (DBApp (DBAbs _ _) _) = False
isNormalForm (DBApp e1 e2)         = isNormalForm e1 && isNormalForm e2
isNormalForm (DBAbs _ e)           = isNormalForm e
isNormalForm _                     = True

shift :: Int -> Int -> DeBruijn -> DeBruijn
shift d k (DBVar n)
  | n >= k    = DBVar (n + d)
  | otherwise = DBVar n
shift d k (DBApp e1 e2) = DBApp (shift d k e1) (shift d k e2)
shift d k (DBAbs x e)   = DBAbs x (shift d (k + 1) e)
shift _ _ e             = e

subst :: Int -> DeBruijn -> DeBruijn -> DeBruijn
subst t v (DBVar n)
  | n == t    = v
  | n > t     = DBVar (n - 1)
  | otherwise = DBVar n
subst t v (DBApp e1 e2) = DBApp (subst t v e1) (subst t v e2)
subst t v (DBAbs x e)   = DBAbs x (subst (t + 1) (shift 1 0 v) e)
subst _ _ e             = e

reduce :: DeBruijn -> DeBruijn -> DeBruijn
reduce = subst 0

normalStep :: DeBruijn -> DeBruijn
normalStep (DBApp (DBAbs _ body) e) = reduce e body
normalStep (DBApp e1 e2)
  | not (isNormalForm e1) = DBApp (normalStep e1) e2
  | otherwise             = DBApp e1 (normalStep e2)
normalStep (DBAbs x e) = DBAbs x (normalStep e)
normalStep e           = e

applicativeStep :: DeBruijn -> DeBruijn
applicativeStep (DBApp (DBAbs _ body) e)
  | isNormalForm body && isNormalForm e = reduce e body
applicativeStep (DBApp e1 e2)
  | not (isNormalForm e1) = DBApp (applicativeStep e1) e2
  | otherwise             = DBApp e1 (applicativeStep e2)
applicativeStep (DBAbs x e) = DBAbs x (applicativeStep e)
applicativeStep e           = e

simplify :: (DeBruijn -> DeBruijn) -> DeBruijn -> [DeBruijn]
simplify step e
  | isNormalForm e = [e]
  | otherwise      = e : simplify step (step e)

normal :: DeBruijn -> [DeBruijn]
normal = simplify normalStep

applicative :: DeBruijn -> [DeBruijn]
applicative = simplify applicativeStep
